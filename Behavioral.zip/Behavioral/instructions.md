### Brief Model Description

MBITES is a software package for simulating adult mosquito ecology and behavior. The purpose is to advance the science and analysis for problems related to mosquito-borne pathogen transmission and vector control.

### Instructions

To start, please choose the "Launch a project" on the left.

### More Information

Click the "About" tab for more information about the model, project and people involved.

